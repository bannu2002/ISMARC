(function ($) {
    "use strict";

    $(document).ready(function($){
        
        // testimonial sliders
        $(".testimonial-sliders").owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
            responsive:{
                0:{
                    items:1,
                    nav:false
                },
                600:{
                    items:1,
                    nav:false
                },
                1000:{
                    items:1,
                    nav:false,
                    loop:true
                }
            }
        });

        // homepage slider
        $(".homepage-slider").owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
            nav: true,
            dots: false,
            navText: ['<i class="fas fa-angle-left"></i>', '<i class="fas fa-angle-right"></i>'],
            responsive:{
                0:{
                    items:1,
                    nav:false,
                    loop:true
                },
                600:{
                    items:1,
                    nav:true,
                    loop:true
                },
                1000:{
                    items:1,
                    nav:true,
                    loop:true
                }
            }
        });

        // logo carousel
        $(".logo-carousel-inner").owlCarousel({
            items: 4,
            loop: true,
            autoplay: true,
            margin: 30,
            responsive:{
                0:{
                    items:1,
                    nav:false
                },
                600:{
                    items:3,
                    nav:false
                },
                1000:{
                    items:4,
                    nav:false,
                    loop:true
                }
            }
        });

        // count down
        if($('.time-countdown').length){  
            $('.time-countdown').each(function() {
            var $this = $(this), finalDate = $(this).data('countdown');
            $this.countdown(finalDate, function(event) {
                var $this = $(this).html(event.strftime('' + '<div class="counter-column"><div class="inner"><span class="count">%D</span>Days</div></div> ' + '<div class="counter-column"><div class="inner"><span class="count">%H</span>Hours</div></div>  ' + '<div class="counter-column"><div class="inner"><span class="count">%M</span>Mins</div></div>  ' + '<div class="counter-column"><div class="inner"><span class="count">%S</span>Secs</div></div>'));
            });
         });
        }

        // projects filters isotop
        $(".product-filters li").on('click', function () {
            
            $(".product-filters li").removeClass("active");
            $(this).addClass("active");

            var selector = $(this).attr('data-filter');

            $(".product-lists").isotope({
                filter: selector,
            });
            
        });

        $('.gatepass_button').click(function(){
            // console.log(10);
            var name = $(this).data('name');
            var phone = $(this).data('phone');
            var reason = $(this).data('reason');
            let html = '<a  style="color: white" class="btn btn-success font-size-12 ">In the Cart</a>';
            $('.addToCartSubmit[data-item='+item_id+']').parent().html(html);
            // $('.cart-value').html(value);
            // console.log(value);
            $.ajax({
                url: 'addtocart.php',
                method: 'post',
                data: {item_id: item_id, user_id: user_id},
                success: function(data){
                    console.log(data);
                    loadCartNumber(user_id);
                }
            })
        })
        // isotop inner
        $(".product-lists").isotope();

        // magnific popup
        $('.popup-youtube').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: false,
            fixedContentPos: false
        });

        // light box
        $('.image-popup-vertical-fit').magnificPopup({
            type: 'image',
            closeOnContentClick: true,
            mainClass: 'mfp-img-mobile',
            image: {
                verticalFit: true
            }
        });

        // homepage slides animations
        $(".homepage-slider").on("translate.owl.carousel", function(){
            $(".hero-text-tablecell .subtitle").removeClass("animated fadeInUp").css({'opacity': '0'});
            $(".hero-text-tablecell h1").removeClass("animated fadeInUp").css({'opacity': '0', 'animation-delay' : '0.3s'});
            $(".hero-btns").removeClass("animated fadeInUp").css({'opacity': '0', 'animation-delay' : '0.5s'});
        });

        $(".homepage-slider").on("translated.owl.carousel", function(){
            $(".hero-text-tablecell .subtitle").addClass("animated fadeInUp").css({'opacity': '0'});
            $(".hero-text-tablecell h1").addClass("animated fadeInUp").css({'opacity': '0', 'animation-delay' : '0.3s'});
            $(".hero-btns").addClass("animated fadeInUp").css({'opacity': '0', 'animation-delay' : '0.5s'});
        });

       

        // stikcy js
        $("#sticker").sticky({
            topSpacing: 0
        });

        //mean menu
        $('.main-menu').meanmenu({
            meanMenuContainer: '.mobile-menu',
            meanScreenWidth: "992"
        });
        
         // search form
        $(".search-bar-icon").on("click", function(){
            $(".search-area").addClass("search-active");
        });

        $(".close-btn").on("click", function() {
            $(".search-area").removeClass("search-active");
        });

        $('.gatepassSubmit').click(function(){
            // $('#hiding').toggle();

            // $(this).toggle();
            // $('.gatepassSubmitNew').toggle();

            var name = $("#gatepassName").val();
            var phone = $("#gatepassPhone").val();
            var reason = $("#gatepassReason").val();
            var randomCode = $("#gatepassCode").val();  
            
            if(name != "" && phone != "" && reason != ""){

                $('#hiding').toggle();
                $(this).toggle();
                $('.gatepassSubmitNew').toggle();

                var ID = $("#gatepassID").val(); 
                
                console.log("added",name, phone, reason, randomCode);
                console.log(ID);

                $.ajax({
                    url: "gatepass-hid.php",
                    method: "post",
                    data: {name: name, phone: phone, reason: reason, randomCode: randomCode, ID: ID},
                    dataType: "text",
                    success: function(data){
                        console.log("added",name, phone, reason, randomCode);
                        console.log(data);
                    }
                })             
            }

            else{
                alert("Fill in all the required fields");
            }
            

        })

        $('.hidingCopy').click(function(){
            console.log("copied");
            var r = document.createRange();
            r.selectNode(document.getElementById("hidingCode"));
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(r);
            document.execCommand('copy');
            window.getSelection().removeAllRanges();
            alert("Copied the text");
        })

        $('.security-approval-button').click(function(){
            var itemid = $(this).data("item");
            var html = '<a class="btn btn-success" style="border-radius: 5px">Approved</a>'
            $(this).parent().html(html);

            $.ajax({
                url: 'approval-hid.php',
                method: 'post',
                data: {itemid: itemid},
                success: function(){
                    console.log("updated");
                }
            })

            console.log(itemid);
        })

        $('.security-ground-button').click(function(){
            var venueid = $(this).data("venue");
            // var html = '<a class="btn btn-success" style="border-radius: 5px">Approved</a>'
            // $(this).parent().html(html);

            var that = this;
            var status = null;

            if($(this).hasClass("cart-btn2")){
                status = "available";
                $(that).html("Available");
                $(that).removeClass("cart-btn2");
                $(that).addClass("cart-btn1");
            }
            else{
                status = "unavailable";
                $(that).html("Unavailable");
                $(that).removeClass("cart-btn1");
                $(that).addClass("cart-btn2");
            }

            $.ajax({
                url: 'security-ground-hid.php',
                method: 'post',
                data: {venueid: venueid, status: status},
                dataType: 'text',
                success: function(data){
                    console.log("updated ".concat(data));
                }
            })

            console.log(venueid);
        })

        $('.security-room-button').click(function(){
            var roomid = $(this).data("room");
            // var html = '<a class="btn btn-success" style="border-radius: 5px">Approved</a>'
            // $(this).parent().html(html);

            var that = this;
            var status = null;

            if($(this).hasClass("cart-btn2")){
                status = "available";
                $(that).html("Available");
                $(that).removeClass("cart-btn2");
                $(that).addClass("cart-btn1");
            }
            else{
                status = "unavailable";
                $(that).html("Unavailable");
                $(that).removeClass("cart-btn1");
                $(that).addClass("cart-btn2");
            }

            $.ajax({
                url: 'security-room-hid.php',
                method: 'post',
                data: {roomid: roomid, status: status},
                dataType: 'text',
                success: function(data){
                    console.log("updated ".concat(data));
                }
            })

            console.log(roomid);
        })

        // $('.input-group-text').click(function(){
        //     $('#datepicker').datepicker({ minDate: new Date()});
        //     $('#datepicker').datepicker();
        // })

        $('#showSlots').click(function(){
            var date = $("#datepicker").datepicker("getDate");
            var date1 = new Date(date);
            console.log(date1.toDateString());
        })

        $('.slotTimes').click(function(){
            var user = $(this).data("user");
            var from = $(this).data("from");
            var date = $(this).data("date");
            var room = $(this).data("room");
            var price = $(this).data("price");

            console.log(from,date,room,price);
            var result = false;
            if($(this).hasClass("btn-outline-primary"))
                result = confirm("confirm booking from ".concat(from,":00 to ",from+1,":00 ?"));

            var that = this;
            if(result == true){
                $.ajax({
                    url: 'slotbooking-hid.php',
                    method: 'post',
                    data: {from: from, date: date, room: room, user: user, price: price},
                    dataType: 'text',
                    success: function(data){
                        // flag = 1;
                        // if(flag == 1)
                        if(data != "rejected"){
                            $(that).removeClass("btn-outline-primary").addClass("btn-outline-warning");
                            $(that).addClass('flagClass');
                            $('.flagClass').removeClass("slotTimes");
                            console.log("success".concat(data));
                        }
                        else{
                            alert("Booking Failed, Insufficient Balance!");
                        }
                    }   
                })
            }
        })

        $('.slotTimesGround').click(function(){
            var user = $(this).data("user");
            var from = $(this).data("from");
            var date = $(this).data("date");
            var venue = $(this).data("venue");
            var price = $(this).data("price");

            console.log(from,date,venue,price);
            var result = false;
            if($(this).hasClass("btn-outline-primary"))
                result = confirm("confirm booking from ".concat(from,":00 to ",from+1,":00 ?"));

            var that = this;
            if(result == true){
                $.ajax({
                    url: 'venuebooking-hid.php',
                    method: 'post',
                    data: {from: from, date: date, venue: venue, user: user, price: price},
                    dataType: 'text',
                    success: function(data){
                        // flag = 1;
                        // if(flag == 1)
                        if(data != "rejected"){
                            $(that).removeClass("btn-outline-primary").addClass("btn-outline-warning");
                            console.log("success".concat(data));
                        }
                        else{
                            alert("Booking Failed, Insufficient Balance!");
                        }
                    }   
                })
            }
        })
    
    });

    


    jQuery(window).on("load",function(){
        jQuery(".loader").fadeOut(1000);
    });

    loadpage();
        function loadpage(){
            $.ajax({
                url: "adminDetails.php",
                method: "post",
                data: {action: 'loadpage'},
                dataType: "JSON",
                success: function(data){
                    console.log(data);
                    $('#clubbookings').html("₹"+data.clubbookings);
                    $('#venuebookings').html("₹"+data.venuebookings);
                    $('#revenuebookings').html("₹"+data.revenuebookings);
                    $('#totaltransactions').html(data.totaltransactions);
                    $('#totalvendors').html(data.totalvendors);
                    $('#revenuepaylater').html("₹"+data.revenuepaylater);
                }
            })
        }


}(jQuery));